using ActuArte.Models;
using ActuArte.Business;
using Microsoft.AspNetCore.Mvc;

namespace ActuArte.Controllers
{
    [ApiController]
    [Route("[controller]")]


    public class ObrasController : ControllerBase
    {


        private readonly ObrasService _obrasService;


        public ObrasController(ObrasService obrasService)
        {
            _obrasService = obrasService;
        }



        [HttpGet]
        public ActionResult<List<Obras>> GetAll() =>
            _obrasService.GetAll();



        [HttpGet("{id}")]
        public ActionResult<Obras?> Get(int id)
        {
            var obras = _obrasService.Get(id);

            if (obras == null)
                return NotFound();

            return obras;
        }

        
    }
}