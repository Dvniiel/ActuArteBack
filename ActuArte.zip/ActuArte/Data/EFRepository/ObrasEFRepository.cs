using ActuArte.Models;
using Microsoft.EntityFrameworkCore;

namespace ActuArte.Data
{
    public class ObraEFRepository : IObraRepository
    {
        private readonly ActuArteContext _context;

        public ObraEFRepository(ActuArteContext context)
        {
            _context = context;
        }

        // GET ALL OBRAS
        public List<Obras> GetAll()
        {
            return _context.Obras.ToList();
        }

        //GET POR ID
        public Obras Get(int Id)
        {
            return _context.Obras.FirstOrDefault(obras => obras.idObra == Id);
        }

        // UPDATE
        public void Update(Obras obras)
        {
            _context.Obras.Update(obras);
            SaveChanges();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}