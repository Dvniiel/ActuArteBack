using ActuArte.Models;
using ActuArte.Data;

namespace ActuArte.Business
{
    public class ObrasService : IObrasService
    {
        private readonly IObrasRepository _obrasRepository;

        public ObrasService(IObrasService obrasRepository)
        {
            _obrasRepository = obrasRepository;
        }

        public Obras? Get(int id) => _obrasRepository.Get(id);
        public List<Obras> GetAll() => _obrasRepository.GetAll();
    }
}