﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ActuArte.Models;

public class Obras
{
    [Key]
    public int  idObra { get; set; }


    [Required]
    public string?  nombreObra { get; set; }


    public string? descObra { get; set; }


    public double precioObra { get; set; }


    public double valoracionObra { get; set; }
}
