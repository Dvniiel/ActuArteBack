using ActuArte.Models;

namespace ActuArte.Data
{
    public interface IAsientosRepository
    {
        Asientos Get(int id); // Corregido para devolver un objeto Asientos

        List<Asientos> GetAll();
    }
}