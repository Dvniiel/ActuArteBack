﻿
namespace ActuArte.Data
{
    public class ActuArteContext
    {

    }
}
