using ActuArte.Models;
using Microsoft.EntityFrameworkCore;

namespace ActuArte.Data
{
    public class AsientosEFRepository : IAsientosRepository
    {
        private readonly ActuArteContext _context;

        public AsientosEFRepository(ActuArteContext context)
        {
            _context = context;
        }

        public List<Asientos> GetAll()
        {
            return _context.Asientos.ToList();
           
        }
        

        public Asientos Get(int Id)
        {
            return _context.Asientos.FirstOrDefault(ingredientes => asientos.idAsiento == Id);
    
        }


        public void Update(Asientos asientos)
        {
            _context.Asientos.Update(asientos);
            SaveChanges();
        }



        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}