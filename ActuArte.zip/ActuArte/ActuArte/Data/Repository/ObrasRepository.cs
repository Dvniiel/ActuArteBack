using System.Collections.Generic;
using System.Linq;
using ActuArte.Models;
using Microsoft.EntityFrameworkCore;

namespace ActuArte.Data
{
    public class ObrasRepository : IObrasRepository
    {
        private readonly MiDbContext _context;

        public ObrasRepository(MiDbContext context)
        {
            _context = context;
        }

        public List<Obras> GetAll()
        {
            return _context.Obras.ToList();
        }

        public Obras Get(int Id)
        {
            return _context.Obras.FirstOrDefault(o => o.IdObra == Id);
        }

        public void Update(Obras obras)
        {
            _context.Obras.Update(obras);
            _context.SaveChanges();
        }
    }
}