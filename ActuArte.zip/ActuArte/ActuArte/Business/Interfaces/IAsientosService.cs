using System.Dynamic;
using ActuArte.Models;

namespace ActuArte.Business
{
    public interface IAsientosService
    {
        
    }
}
