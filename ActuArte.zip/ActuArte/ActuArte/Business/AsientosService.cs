using ActuArte.Models;
using ActuArte.Data;

namespace ActuArte.Business
{
    public class AsientosService : IAsientosService
    {
        private readonly IAsientosRepository _asientosRepository;

        public AsientosService(IAsientosService asientosRepository)
        {
            _asientosRepository = asientosRepository;
        }

        
    }
}