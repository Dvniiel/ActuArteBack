using ActuArte.Models;
using ActuArte.Data;

namespace ActuArte.Business
{
    public class ObrasService
    {
        private readonly MiDbContext _context;

        public ObraService(MiDbContext context)
        {
            _context = context;
        }

        public async Task<List<ObraDTO>> ObtenerObrasAsync()
        {
            return await _context.Obras
                .Select(o => new ObraDTO
                {
                    IdObra = o.idObra,
                    NombreObra = o.nombreObra,
                    Imagen = o.imagen
                })
                .ToListAsync();
        }
    }
}