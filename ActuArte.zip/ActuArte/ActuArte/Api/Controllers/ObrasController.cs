using ActuArte.Models;
using ActuArte.Business;
using Microsoft.AspNetCore.Mvc;

namespace ActuArte.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class ObrasController : ControllerBase
    {
        private readonly ObrasService _obraService;

        public ObrasController(ObrasService obraService)
        {
            _obraService = obraService;
        }

        [HttpGet]
        public async Task<ActionResult<List<ObraDto>>> Get()
        {
            try
            {
                var obras = await _obraService.ObtenerObrasAsync();
                return Ok(obras);
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                return StatusCode(500, "Error interno del servidor");
            }
        }
    }
}