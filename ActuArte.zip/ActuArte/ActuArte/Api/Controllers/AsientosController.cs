using ActuArte.Models;
using ActuArte.Business;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace TetePizza.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AsientosController : ControllerBase
    {


        private readonly AsientosService _asientosService;



        public AsientosController(AsientosService asientosService)
        {
            _asientosService = asientosService;
        }



        [HttpGet]
        public ActionResult<List<Asientos>> GetAll() => _asientosService.GetAll();



        [HttpGet("{id}")]
        public ActionResult<Asientos> Get(int id)
        {
            var asientos = _asientosService.Get(id);

            if (asientos == null)
                return NotFound();

            return asientos;
        }



        [HttpPost]
        public IActionResult Create(Asientos asientos)
        {
            _asientosService.Add(asientos);
            return CreatedAtAction(nameof(Get), new { id = asientos.idAsiento }, asientos);
        }



        [HttpPut("{id}")]
        public IActionResult Update(int id, Asientos asientos)
        {
            if (id != asientos.idAsiento)
                return BadRequest();

            var existingPizza = _asientosService.Get(id);
            if (existingPizza is null)
                return NotFound();

            _asientosService.Update(asientos);

            return NoContent();
        }




        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var pizza = _asientosService.Get(id);

            if (pizza is null)
                return NotFound();

            _asientosService.Delete(id);

            return NoContent();
        }
    }
}
