using ActuArte.Services;
using ActuArte.Controllers;
using ActuArte.Models;
using ActuArte.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Agrega servicios al contenedor.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var isRunningInDocker = Environment.GetEnvironmentVariable("DOCKER_CONTAINER") == "true";
var keyString = isRunningInDocker ? "ServerDB_Docker" : "ServerDB_Local";
var connectionString = builder.Configuration.GetConnectionString(keyString);

builder.Services.AddDbContext<MiDbContext>(options => 
    options.UseSqlServer(builder.Configuration.GetConnectionString("MiCadenaDeConexion")));

builder.Services.AddScoped<ObrasService>();

// OBRAS
builder.Services.AddScoped<ObrasService>();
builder.Services.AddScoped<IObrasRepository, ObrasEFRepository>();

// ASIENTOS
builder.Services.AddScoped<AsientosService>();
builder.Services.AddScoped<IAsientosRepository, AsientosEFRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();